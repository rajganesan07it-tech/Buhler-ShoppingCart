<template>
  <header class="header">
    <div class="logo">
      <img src="/assets/logo.png" width="500" height="100" />
    </div>
    <div>
      {{ formattedDate }}
    </div>
    <div>
      <router-link to="/checkout" class="cart-link">
        <img src="/assets/shoppingCart.svg" width="20" height="20" /> Cart ({{
          cartStore.getSelectedItemCount
        }})
      </router-link>
    </div>
  </header>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useCartStore } from '../store/cart'
const cartStore = useCartStore()

const currentDate = ref(new Date())
setInterval(() => {
  currentDate.value = new Date()
}, 1000)
const monthShortNames = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
]
const formattedDate = computed(() => {
  const date = currentDate.value
  const year = date.getFullYear()
  const month = monthShortNames[date.getMonth()]
  const day = String(date.getDate()).padStart(2, '0')
  let hour = date.getHours()
  const minute = String(date.getMinutes()).padStart(2, '0')
  const second = String(date.getSeconds()).padStart(2, '0')
  const ampm = hour >= 12 ? 'PM' : 'AM'
  hour = hour % 12
  hour = hour ? hour : 12
  hour = String(hour).padStart(2, '0')
  return `${month}/${day}/${year}, ${hour}:${minute}:${second} ${ampm}`
})
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background: #f1f1f1;
  color: #00aa9d;
  border-bottom: 7px solid #00aa9d;
}
.cart-link {
  color: #00aa9d;
  text-decoration: none;
  font-size: 1.2rem;
}
</style>
<script></script>
