import { defineStore } from 'pinia'

export const useCartStore = defineStore('cart', {
  state: () => ({
    selectedItemCount: 0 as Number,
    selectedItems: [] as any[],
  }),
  actions: {
    setSelectedItemCount() {
      this.selectedItemCount = this.selectedItemCount + 1
    },
    setSelectedItems(items: any[]) {
      this.selectedItems.push(items)
    },
  },
  getters: {
    getSelectedItemCount(): any {
      return this.selectedItemCount
    },
    getSelectedItems(): any[] {
      return this.selectedItems
    },
  },
})
