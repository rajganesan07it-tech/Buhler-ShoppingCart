<script setup lang="ts">
import Header from './components/Header.vue'
import { ref } from 'vue'
</script>

<template>
  <Header />
  <router-view />
</template>

<style scoped></style>
