<template>
  <div class="productContainer">
    <div v-for="(products, category) in groupedProducts" :key="category">
      <h2>{{ category }}</h2>
      <div class="flex-layout">
        <div v-for="product in products" :key="product.id" class="product-card">
          <img :src="product.imageUrl" width="250" height="200" />
          <div class="product-details dflex">
            <div class="flexFullWidth textleft textBold">
              {{ product.name }}
            </div>
            <div class="flexFullWidth dflex p-tb-10">
              <div class="flexhalfWidth textleft">x{{ product.price }}</div>
              <router-link :to="`/products/${product.id}`" class="product-title"
                ><img src="/assets/shoppingCart.svg" width="20" height="20" />
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import productsData from '../json/product.json'
const categoryNames: Record<string, string> = {
  machine_roller: 'Rollers',
  machine_sorter: 'Optical Sorters',
  machine_dryer: 'Dryers',
  machine_die_casting: 'Die Casting Machines',
}

const groupedProducts = computed(() => {
  const groups: Record<string, any[]> = {}
  for (const product of productsData) {
    const displayName = categoryNames[product.category] || product.category
    if (!groups[displayName]) groups[displayName] = []
    groups[displayName].push(product)
  }
  return groups
})
</script>

<style scoped>
.flex-layout {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  flex-direction: row;
}
.product-card {
  border: 1px solid #ccc;
  text-align: center;
  background: #fafafa;
  border-radius: 4px;
  width: 250px;
}
.productContainer {
  color: #00aa9d;
  padding: 40px;
}
.product-details {
  display: flex;
  padding: 0.5rem;
  font-weight: 100;
  font-size: 16px;
  background: #f1f1f1;
  flex-direction: row;
  flex-wrap: wrap;
}
</style>
