<template>
  <div class="checkoutContainer">
    <h2>Checkout</h2>
    <div v-if="selectedItems.length > 0">
      <div v-for="(item, idx) in selectedItems" :key="item._value.id" class="dflex checkoutItem">
        <div class="checkoutItemImage dflex">
          <img :src="item._value.imageUrl" width="250" height="200" />
          <span class="itemName">{{ item._value.name }}</span>
          <span>{{ categoryName }}</span>
        </div>
        <div class="checkoutItemDetails">
          <span class="itemPrice">{{ item._value.price }}</span>
        </div>
      </div>
    </div>
    <div v-else>
      <p>No items in cart.</p>
    </div>
    <div class="total f_right">
      Total: {{ selectedItems.reduce((total, item) => total + parseFloat(item._value.price), 0) }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useCartStore } from '../store/cart'

const cartStore = useCartStore()
const selectedItems = cartStore.getSelectedItems
const categoryNames: Record<string, string> = {
  machine_roller: 'Rollers',
  machine_sorter: 'Optical Sorters',
  machine_dryer: 'Dryers',
  machine_die_casting: 'Die Casting Machines',
}
const categoryName = computed(() => {
  selectedItems.forEach((selectedItem) => {
    if (selectedItem._value) {
      return categoryNames[selectedItem._value.category]
    }
  })
})
</script>

<style scoped>
.checkoutItem {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
  border-bottom: 1px solid #eee;
  padding-bottom: 0.5rem;
}
.itemName {
  flex: 1;
  font-weight: bold;
}
.itemPrice {
  margin-right: 20px;
}
.total {
  margin-top: 1rem;
  font-size: 1.2rem;
  font-weight: bold;
}
.checkoutContainer {
  padding: 40px;
  color: #00aa9d;
  background: #f1f1f1;
}
.checkoutContainer h2 {
  padding-bottom: 40px;
}
.itemPrice {
  display: inline-block;
  width: 40px;
}
.checkoutItemDetails {
  flex: 50%;
  text-align: right;
}
.checkoutItemImage {
  flex: 50%;
}
.total {
  font-size: 16px;
}
.checkoutItemImage span {
  padding-left: 20px;
  padding-top: 20px;
}
</style>
