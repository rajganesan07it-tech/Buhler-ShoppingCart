<template>
  <div class="p-40 productContainer">
    <div class="pb-20">
      <a class="backContainer" @click="goBack">Back</a>
    </div>
    <div v-if="product" class="dflex">
      <img :src="product.imageUrl" width="300" height="250" />
      <div class="pl-20">
        <h2>{{ product.name }}</h2>
        <div class="pb-20">{{ categoryName }}</div>
        <div class="pb-20">x{{ product.price }}</div>
        <div class="addToCart">
          <a @click="addToCart(product)"
            ><img src="/assets/shoppingCart.svg" width="20" height="20" /> Add to Cart</a
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import productsData from '../json/product.json'
import { useCartStore } from '../store/cart'

const route = useRoute()
const router = useRouter()
const productId = route.params.id

const cartStore = useCartStore()

const product = computed(() => productsData.find((p: any) => p.id === productId))
const categoryNames: Record<string, string> = {
  machine_roller: 'Rollers',
  machine_sorter: 'Optical Sorters',
  machine_dryer: 'Dryers',
  machine_die_casting: 'Die Casting Machines',
}
const categoryName = computed(() => {
  if (product.value) {
    return categoryNames[product.value.category] || product.value.category
  }
  return ''
})
function goBack() {
  router.push('/')
}
function addToCart() {
  if (product.value) {
    cartStore.setSelectedItems(product)
    cartStore.setSelectedItemCount()
  }
}
</script>
<style scoped>
.p-40 {
  padding: 40px;
}
.backContainer {
  cursor: pointer;
  color: #00aa9d;
  padding-bottom: 20px;
}
.pb-20 {
  padding-bottom: 20px;
}
.pl-20 {
  padding-left: 20px;
}
.productContainer {
  color: #00aa9d;
}
.addToCart {
  padding-top: 40px;
  cursor: pointer;
}
</style>
