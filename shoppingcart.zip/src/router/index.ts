import { createRouter, createWebHistory } from 'vue-router'
import Product from '../components/Product.vue'
import ProductDetail from '../components/ProductDetails.vue'
import Checkout from '../components/Checkout.vue'

const routes = [
  { path: '/', component: Product },
  { path: '/products/:id', component: ProductDetail, props: true },
  { path: '/checkout', component: Checkout },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

export default router
